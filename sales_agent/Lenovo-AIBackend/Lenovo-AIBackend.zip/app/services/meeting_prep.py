from datetime import datetime, timedelta
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import func, table, column
from app.schema.meeting_prep import CreateMeetingRequest
from app.models.schedulemeeting import MeetingDetails
import uuid
from app.graphapi.meetinginvite import (
    create_teams_meeting_invite,
    reschedule_teams_meeting_invite,
    cancel_teams_meeting_invite
)


def get_upcoming_meetings(
    db: Session,
    filter_type: str,
    seller_id: str | None = None,
):
    now = datetime.now()
    
    query = db.query(MeetingDetails).filter(
        MeetingDetails.bot_status != "completed"
    )
    
    # now = MeetingDetails.meeting_endtime if MeetingDetails.meeting_endtime else datetime.now() + timedelta(minutes=30)

    seller_uuid = None
    if seller_id and seller_id.strip():
        try:
            seller_uuid = UUID(seller_id.strip())
            query = query.filter(MeetingDetails.seller_id == seller_uuid)
        except ValueError:
            raise ValueError("sellerId must be a valid UUID.")

    if filter_type == "all_meetings":
        query = query.filter(
            MeetingDetails.meeting_start_time > now
        )
  


    elif filter_type == "today":
        query = query.filter(
            func.date(
                MeetingDetails.meeting_start_time
            ) == now.date()
        )

    elif filter_type == "tomorrow":
        tomorrow = now.date() + timedelta(days=1)

        query = query.filter(
            func.date(
                MeetingDetails.meeting_start_time
            ) == tomorrow
        )

    elif filter_type == "this_week":

        today = now.date()

        # Sunday -> Saturday
        days_since_sunday = (today.weekday() + 1) % 7

        start_of_week = today - timedelta(days=days_since_sunday)
        end_of_week = start_of_week + timedelta(days=6)

        query = query.filter(
            func.date(MeetingDetails.meeting_start_time) >= start_of_week
        ).filter(
            func.date(MeetingDetails.meeting_start_time) <= end_of_week
        ).filter(
            MeetingDetails.meeting_start_time > now
        )

    else:
        raise ValueError(
            "filter_type must be one of: "
            "all_meetings, today, tomorrow, this_week"
        )

    # Inner join calendar_events on join_url = tbl_schedule_meetings.body to
    # pull the passcode and join_meeting_id for each meeting.
    calendar_events = table(
        "calendar_events",
        column("join_url"),
        column("passcode"),
        column("join_meeting_id"),
    )

    rows = (
        query
        .add_columns(
            calendar_events.c.passcode,
            calendar_events.c.join_meeting_id,
        )
        .join(
            calendar_events,
            calendar_events.c.join_url == MeetingDetails.body,
        )
        .order_by(MeetingDetails.meeting_start_time.asc())
        .all()
    )
    
    # Today's and tomorrow's upcoming meeting counts (independent of the
    # requested filter, but scoped to the same seller).
    today = now.date()
    tomorrow = today + timedelta(days=1)

    count_base = db.query(func.count(MeetingDetails.meeting_id))
    if seller_uuid is not None:
        count_base = count_base.filter(MeetingDetails.seller_id == seller_uuid)

    today_upcoming_count = count_base.filter(
        func.date(MeetingDetails.meeting_start_time) == today
    ).filter(
        MeetingDetails.meeting_start_time > now
    ).scalar()

    today_completed_count = count_base.filter(
        func.date(MeetingDetails.meeting_start_time) == today
    ).filter(
        MeetingDetails.meeting_start_time <= now
    ).scalar()

    tomorrow_meeting_count = count_base.filter(
        func.date(MeetingDetails.meeting_start_time) == tomorrow
    ).scalar()

    response = []
   

    for meeting, passcode, join_meeting_id in rows:
        if meeting.attendees_emails:
            attendees_list = [
                email.strip() for email in meeting.attendees_emails.split(",")
            ]
        else:
            attendees_list = []

        prep_pending = 0
        if meeting.seller_id:
            from app.services.briefing_service import count_open_prep_tasks

            prep_pending = count_open_prep_tasks(
                db, str(meeting.meeting_id), meeting.seller_id
            )

        response.append({
            "meeting_id": str(meeting.meeting_id),
            "meeting_start_time": meeting.meeting_start_time,
            "meeting_end_time": meeting.meeting_end_time,
            "platform": meeting.platform,
            "title": meeting.title,
            "account_name": meeting.account_name,
            "organiser_name": meeting.organiser_name,
            "attendees_emails": meeting.attendees_emails,
            "body": meeting.body,
            "attendee_count": len(attendees_list or []),
            "opportunity_id": str(meeting.opportunity_id) if meeting.opportunity_id else None,
            "account_id": str(meeting.account_id) if meeting.account_id else None,
            "meeting_url": meeting.meeting_url,
            "passcode": passcode,
            "join_meeting_id": join_meeting_id,
            "prep_tasks_pending_count": prep_pending,
        })

    return {
        "today_meeting_count": {
            "completed": today_completed_count or 0,
            "upcoming": today_upcoming_count or 0,
            "total": (today_completed_count or 0) + (today_upcoming_count or 0),
        },
        "tomorrow_meeting_count": tomorrow_meeting_count or 0,
        "meetings": response,
    }

def create_meeting(
    payload: CreateMeetingRequest,
    db: Session
):
    
    meeting_end = (
    payload.meeting_end_time
    if payload.meeting_end_time
    else payload.meeting_start_time + timedelta(minutes=30)
)
    seller_uuid = None
    if getattr(payload, "seller_id", None):
        seller_uuid = payload.seller_id

    meeting = MeetingDetails(
        meeting_id=str(uuid.uuid4()),
        meeting_start_time=payload.meeting_start_time,
        meeting_end_time=payload.meeting_end_time or meeting_end,
        platform=payload.platform,
        title=payload.title,
        account_name=payload.account_name,
        attendees_emails=payload.attendees_emails,
        opportunity=payload.opportunity,
        meeting_url=payload.meeting_url,
        prep_notes=payload.prep_notes,
        seller_id=seller_uuid,
    )
    
    db.add(meeting)
    
    db.commit()

    db.refresh(meeting)
    create_teams_meeting_invite(
        recipient_email=payload.attendees_emails, 
        meeting_start=payload.meeting_start_time.strftime("%Y-%m-%d %H:%M"),
        meeting_end=meeting_end.strftime("%Y-%m-%d %H:%M"),
        timezone="Asia/Kolkata",
        meeting_subject=payload.title
       
    )

    return {
        "success": True,
        "message": "Meeting created successfully"
        
    }